﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorScript : MonoBehaviour
{
    public int jarsRequired;
    public int ZCoordinateToStopMoving;

    int doorSpeed = 10;
    bool doneMoving = false;

    void Update()
    {
        if (doneMoving == false)
        {
            if (GameObject.Find("PlayerBee").GetComponent<PlayerScript>().coinsCollected == jarsRequired)
            {
                transform.Translate(Vector3.forward * doorSpeed * Time.deltaTime);
            }
            if(transform.position.z > ZCoordinateToStopMoving)
            {
                doneMoving = true;
            }
        }
    }
}
