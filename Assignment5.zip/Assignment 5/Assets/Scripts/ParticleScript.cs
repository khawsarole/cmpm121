﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleScript : MonoBehaviour
{
    public GameObject HoneyJar;
    public ParticleSystem particle;
    bool particleEmitted = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(HoneyJar == null)
        {
            if (particleEmitted == false)
            {
                particle.Emit(10);
                particleEmitted = true;
            }
        }
    }
}
