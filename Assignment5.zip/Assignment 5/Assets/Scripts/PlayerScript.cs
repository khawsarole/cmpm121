﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    int posSpeed = 10;
    int jumpHeight = 500;
    public int coinsCollected = 0;
    public int count;
    public Text countText;

    // Start is called before the first frame update
    void Start()
    {
        //Move: WASD
        //Jump: Space
        //Reset: R
        count = 0;
        SetCountText();
    }

    // Update is called once per frame
    void Update()
    {
        //Movement
        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(Vector3.forward * posSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector3.left * posSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(Vector3.back * posSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.right * posSpeed * Time.deltaTime);
        }
        /*
        //Make sure cube doesnt tip over :(
        transform.eulerAngles = new Vector3(0f, 0f, 0f);*/
        transform.Rotate(0, Input.GetAxis("Mouse X"), 0);

        //Jump
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (transform.position.y < 0)
            {
                GetComponent<Rigidbody>().AddForce(transform.up * jumpHeight);
            }
        }

        //Reset
        if (Input.GetKeyDown(KeyCode.R))
        {
            transform.TransformPoint(Vector3.zero);
            transform.eulerAngles = new Vector3(0f, 0f, 0f);
        }
        /*
        if (Input.GetKeyDown(KeyCode.O))
        {
            Debug.Log(coinsCollected);
        }*/
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Honey!"))
        {
            other.gameObject.SetActive(false);
            count += 1;
            SetCountText();
        }
    }

    void SetCountText()
    {
        countText.text = "Honey: " + count.ToString() + "/11";
    }
}




