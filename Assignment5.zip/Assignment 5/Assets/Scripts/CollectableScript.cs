﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectableScript : MonoBehaviour
{
    bool up = false;
    int counter = 0;
    int bounceSpeed = 1;

    // Start is called before the first frame update
    void Start()
    {
        transform.Rotate(new Vector3(0, Random.Range(0, 360), 0));
    }

    void OnTriggerEnter(Collider other)
    {
        Destroy(gameObject);
        GameObject.Find("PlayerBee").GetComponent<PlayerScript>().coinsCollected++;
        //Debug.Log("Coins: " + GameObject.Find("PlayerBee").GetComponent<PlayerScript>().coinsCollected);
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(new Vector3(0, 40, 0) * Time.deltaTime);
        if (up)
        {
            transform.Translate(Vector3.down * bounceSpeed * Time.deltaTime);
            counter++;
            if (counter > 50)
            {
                up = false;
                counter = 0;
            }
        }
        else
        {
            transform.Translate(Vector3.up * bounceSpeed * Time.deltaTime);
            counter++;
            if (counter > 50)
            {
                up = true;
                counter = 0;
            }
        }
    }
}