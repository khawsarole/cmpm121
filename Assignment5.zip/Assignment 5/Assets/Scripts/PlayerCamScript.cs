﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Tutorial for camera: https://code.tutsplus.com/tutorials/unity3d-third-person-cameras--mobile-11230

public class PlayerCamScript : MonoBehaviour
{
    public Camera playerCam;
    public Camera spawnCam;

    public GameObject target;
    Vector3 offset;
    bool gameStarted = false;
    private void Start()
    {
        spawnCam.enabled = true;
        playerCam.enabled = false;
        offset = target.transform.position - transform.position;
    }
    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.D))
        {
            spawnCam.enabled = false;
            playerCam.enabled = true;
            gameStarted = true;
        }
        if(gameStarted == true)
        {
            float currentAngle = transform.eulerAngles.y;
            float desiredAngle = target.transform.eulerAngles.y;
            float angle = Mathf.LerpAngle(currentAngle, desiredAngle, Time.deltaTime * 100);
            Quaternion rotation = Quaternion.Euler(0, angle, 0);
            transform.position = target.transform.position - (rotation * offset);
            transform.position = new Vector3(transform.position.x, transform.position.y + 6f, transform.position.z);
            transform.LookAt(target.transform);
        }
    }
}





